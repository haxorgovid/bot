#!/bin/bash
# Bot Marlboro Coded By Achon666ju5t - Demeter16
rm vid.txt
rm coba.txt
GREEN='\e[38;5;82m'
CYAN='\e[38;5;39m'
RED='\e[38;5;196m'
YELLOW='\e[93m'
PING='\e[38;5;198m'
BLUE='\033[0;34m'
NC='\033[0m'
BLINK='\e[5m'
HIDDEN='\e[8m'
start=$(date +%R)
printf "Started at: ${PING}${start} | ${CYAN}`pwd`${NC}\n"
gas(){
    decide_csrf=$(echo $(get_csrf) | grep -Po "(?<=name\=\"decide_csrf\" value\=\").*?(?=\" />)" | head -1)
        ceklogin=$(login $emails $pw $decide_csrf | grep -Po "(?<=\"message\":\").*?(?=\")")
        if [[ "$ceklogin" =~ 'Akun lo telah dikunci' ]]; then
            echo "${emails} | Akun Dikunci (locked)"
 echo "${emails} | Akun Dikunci (locked)">> locked.txt
        elif [[ "$ceklogin" =~ 'Email atau password yang lo masukan salah' ]]; then
            echo -n "Wrong Password"
            break
        elif [[ "$ceklogin" =~ 'success' ]]; then
            nonton=$(cat vid.txt | shuf | head -1)
            cat vid.txt | grep -v "$nonton" > vid.txt.tmp && mv vid.txt.tmp vid.txt &> /dev/null
            lalajo=$(nonton_video $nonton $decide_csrf)
            lid=$(echo $lalajo | jq .data.log_id | tr -d \")
            nobar=$(submit_video $nonton $decide_csrf $lid | jq .data.finished)
            if [[ "$nobar" = 'true' ]]; then
                echo -en "${GREEN}[OK] | ${YELLOW}"
            elif [[ "$lalajo" =~ "Action is not allowed" ]]; then
                echo -en "${YELLOW}[NO] | "
            else
                sleep 29
            fi
        else
            # echo "$ceklogin"
            echo -n "Wrong CSRF | "
        fi
}
login(){
    curl -s -X POST --compressed \
        --url 'https://www.marlboro.id/auth/login?ref_uri=/profile'\
        -H 'Accept-Language: en-US,en;q=0.9' \
        -H 'Connection: keep-alive' \
        -H 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
        -H 'Host: www.marlboro.id' \
        -H 'Origin: https://www.marlboro.id' \
        -H 'Referer: https://www.marlboro.id/' \
        -H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36' \
        -H 'X-Requested-With: XMLHttpRequest' \
        --data-urlencode 'email='$1'' \
        --data-urlencode 'password='$2''\
        --data-urlencode 'decide_csrf='$3'' \
        --data-urlencode 'ref_uri=%252Fprofile0' \
        --cookie-jar $cok -b $cok
}
get_point(){
    curl -s 'https://www.marlboro.id/' -b $cok -c $cok | grep -Po "(?<=<img src=\"/assets/images/icon-point-red.svg\"/><div class=\"point\">).*?(?=\</div></a>)"
}
get_csrf(){
    curl -s 'https://www.marlboro.id/auth/login?ref_uri=/profile' --cookie-jar $cok
}
get_video(){
    curl -s 'https://www.marlboro.id/article/explore?q='$1'&load_more=true&offset='$2'&_=1569878939605' -b $cok -c $cok | jq .data.article[].link_detail | tr -d \" | gawk -F\/ '{ print $6 }' >> coba.txt
}
submit_video(){
    curl -s -X POST -b $cok --cookie-jar $cok \
        --url 'https://www.marlboro.id/article/video-play/'$1 \
        -d 'decide_csrf='$2'&log_id='$3'&duration=30.118&total_duration=30.482667'
}
nonton_video(){
    link=$1
    ssrf=$2
    curl -sL -X POST \
        --url "https://www.marlboro.id/article/video-play/$link" \
        --data-urlencode "decide_csrf=$ssrf" \
        --data-urlencode 'page=undefined' \
        -b $cok --cookie-jar $cok
}
printf "${YELLOW}"
wacing='y'
list='1.txt'
printf "${NC}"
y=$(gawk -F: '{ print $1 }' $list)
x=$(gawk -F: '{ print $2 }' $list)
IFS=$'\r\n' GLOBIGNORE='*' command eval  'email=($y)'
IFS=$'\r\n' GLOBIGNORE='*' command eval  'passw=($x)'
for (( i = 0; i < "${#email[@]}"; i++ )); do
    cok="${emails}.txt"
    decide_csrff=$(echo $(get_csrf) | grep -Po "(?<=name\=\"decide_csrf\" value\=\").*?(?=\" />)" | head -1)
    emails="${email[$i]}"
    pw="${passw[$i]}"
    if [[ ! -f vid.txt ]]; then
        printf "[!]${RED} No Video Found [!]\n[+]${CYAN} Getting Video . . . ."
            baca=$(cat article.txt | head -1)
            cat article.txt | grep -v $baca > article.txt.tmp && mv article.txt.tmp article.txt
            echo "$baca" >> article.txt
            login $emails $pw $decide_csrff &> /dev/null
            curl -s "https://www.marlboro.id/article/explore?q=$baca&load_more=true&offset=7&_=1569878939605" -b $cok -c $cok | jq .data.article[].link_detail | tr -d \" | gawk -F\/ '{ print $6 }' >> coba.txt
            # curl -s https://www.marlboro.id/logout -b $cok -c $cok
        sort -fsu coba.txt >> ks; mv ks vid.txt
        cat vid.txt > salinan_vid.txt
        echo -e "Success Get Video"
    fi
    rm $cok
    decidee_csrff=$(echo $(get_csrf) | grep -Po "(?<=name\=\"decide_csrf\" value\=\").*?(?=\" />)" | head -1)
    login $emails $pw $decidee_csrff &> /dev/null
    let "sebelum=$(get_point)-25"
    w=$(expr $i + 1)
    echo -en "${CYAN}[$w/${#email[@]}] ${YELLOW}$emails | "
    for ((e=0;e<6; e++ )); do
        cok="${emails}${e}.txt"
        gas &
    done
    wait
    decide_csrf=$(echo $(get_csrf) | grep -Po "(?<=name\=\"decide_csrf\" value\=\").*?(?=\" />)" | head -1)
    ceklogin=$(login $emails $pw $decide_csrf | grep -Po "(?<=\"message\":\").*?(?=\")")
    point=$(get_point)
    let "akhir=${point}-${sebelum}"
    echo -e "${sebelum} -> ${point} | Nambah: ${GREEN}${akhir} [+]${NC}"
    cat salinan_vid.txt > vid.txt
    rm *\@*.txt
done
echo -e "${YELLOW}start from ${start} | Ends at: $(date +%R) | ${CYAN}`pwd`"


