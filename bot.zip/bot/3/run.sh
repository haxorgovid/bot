YELLOW='\e[93m'
NC='\033[0m'
countdown() {
    secs=$1
    shift
    msg=$@
    while [ $secs -gt 0 ]
    do
        printf "\r\033[K ${YELLOW}Waiting . %.d $msg" $((secs--))
        sleep 1
    done
    printf "${NC}\n"
}
echo "Time Now: $(date +%R)"
set_time='01'
while true
do
    if [[ "$(date +%H)" != "$set_time" ]]; then
        if [[ "$(date +%H)" > "${set_time}" ]]; then
            time_now=$(expr $(date +%H) - ${set_time})
            conversi_jam=$(expr `expr 24 - ${time_now}` \* 3600)
        else
            conversi_jam=$(expr `expr ${set_time} - $(date +%H)` \* 3600)
        fi
        conversi_menit=$(expr `expr 60 - $(date +%M)` \* 60)
        if [[ `expr ${set_time} - $(date +%H)` = 1 ]]; then
            conversi_jam='0'
        fi
        if [[ `expr ${set_time} - $(date +%H)` =~ '-' ]]; then
          conversi_jam=$(expr ${set_time} - $(date +%H) | tr -d '-')
        fi
        timer=$(expr $conversi_jam + $conversi_menit - 3300 | tr -d '-')
        echo $timer
        countdown $timer "For Next Running"
    else
        bash marl.sh
    fi
done