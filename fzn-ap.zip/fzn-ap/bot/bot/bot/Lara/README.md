# Laravel-PhpUnit-Rce-And-Get-Env-Exploiter
Laravel PhpUnit Rce And Get Env Exploiter

## Screenshot
![Exploiter](https://raw.githubusercontent.com/vsec7/Laravel-PhpUnit-Rce-And-Get-Env-Exploiter/master/rce.jpg)

## Usage
```
chmod +x laraxpl.sh
./laraxpl.sh
```

### By : Versailles ( Sec7or Team ~ Surabaya Hacker Link )
