# GooDorker | [![title](https://img.shields.io/badge/GooDorker-V1.0-blue.svg?style=popout)](https://github.com/florienzh4x/GooDorker/)
Automatic Google Dorker Bash Based

```bash
     .--.
    |o_o |	
    |:_/ |
   //   \ \
  (|     | )
 /\'\_   _/`\
 \___)=(___/
```

## How To Install
```bash
# git clone https://github.com/florienzh4x/GooDorker.git
# cd GooDorker
# chmod +x install
# ./install
```

## OS Tested
<pre>
- Linux Mint x86_64
- Linux Mint i386
- Backbox x86_64
- Ubuntu 18.04 i386
</pre>
